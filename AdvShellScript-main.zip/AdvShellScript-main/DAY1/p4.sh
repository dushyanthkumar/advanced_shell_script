read -p "Enter a filename:" fname

echo "About $fname file details:-
=================================="

ls -l $fname

