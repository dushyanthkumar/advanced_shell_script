
echo $1 $2 $3 $4 $5
echo
echo ${1} ${2} ${3} ${4} ${5}
echo
echo $@
echo $*
echo
echo "Total no.of args:$#"
