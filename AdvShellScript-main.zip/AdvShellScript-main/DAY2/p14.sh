while read -p "Enter some text:" var
do
	echo "$var"
done >r2.log
