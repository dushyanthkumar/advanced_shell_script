if [ -e $1 ];then
 echo "Yes File $1 is exists"
else
 echo "File $1 is not exists"
fi
