
# single line comment
uptime # display cpu loadbalance
echo # empty line

<<Ab
this is multiline comment
uptime is a system command
using uptime will get
cpu loadbalance
its belongs to /proc directory
Ab
echo "End of the script"
