echo "App details:-
---------------------
$myapp running port number:$myport
------------------------------------"
