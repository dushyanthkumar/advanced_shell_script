
app="webApp"
port=3450

fx(){
   var1=150
   total=`expr $var1 + 100`
   echo "Total=$total"
}

