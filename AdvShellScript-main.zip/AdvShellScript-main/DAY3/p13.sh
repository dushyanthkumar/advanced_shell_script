
echo "This is $0 file"

source ./p12
echo "App name is:$app port=$port"
