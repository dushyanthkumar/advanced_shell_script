
echo "This is $0 file"

. ./p12

echo "App $app details:-
------------------------
app=$app port=$port
------------------------"

fx # function Call
